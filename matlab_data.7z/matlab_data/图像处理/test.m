
    camList = webcamlist;
    cam = webcam(1);
    preview(cam);
src = snapshot(cam);
[lightsrc0, rowG, colG, rowR, colR, rowY, colY] = RGB_2_HSV_(src);
%% 提取颜色区域
lightsrc0 = tiquyanse(rowG, rowR, rowY, lightsrc0, colG, src, colR, colY);

%% 



%lightsrc0是前面(一）的链接中用来对三色范围像素点进行存储
%闭运算
lightsrc = biyuansuan(lightsrc0);


%% 



%对连通分量的范围进行约束

[lightsrc, width, height, centre_x, centre_y,lightsrc1,lightx,lighty,error_x,error_y] = return_error(lightsrc);



%% 


