function [cam] = vision_camera_INIT
    camList = webcamlist;
    cam = webcam(1);
    preview(cam);

end