function [F_NOW_LAST, F_INC ]=servo_speed_control(Objs , F_inc, F_NOW)
 while (1)
  if abs(F_inc)<=0.02
      if F_NOW+F_inc > 1
           writePosition(Objs, 1);
      else
          writePosition(Objs, F_NOW+F_inc);
      end
     pause(0.1);
     F_NOW = F_NOW + F_inc;
     F_NOW_LAST = F_NOW;
     F_INC = 0 ;
     break
  else 
    if  F_inc > 0.02
        writePosition(Objs, F_NOW+0.02);
        pause(0.1);
        F_inc= F_inc-0.02;
        F_NOW = F_NOW + 0.02;
    else 
        writePosition(Objs, F_NOW-0.02);
        pause(0.1);
        F_inc= F_inc+0.02;
        F_NOW = F_NOW - 0.02;
    end

  end
 end
end