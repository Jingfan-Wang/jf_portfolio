function lightsrc = biyuansuan(lightsrc0)
lightsrc=rgb2gray(lightsrc0);% 颜色部分二值化、膨胀、腐蚀（不同结构元）(闭运算）
T=graythresh(lightsrc);
lightsrc=im2bw(lightsrc,T);
se1=strel('disk',4);
lightsrc=imdilate(lightsrc,se1);
se2=strel('disk',4);
lightsrc=imerode(lightsrc,se2);

% figure;
% subplot 121;
% imshow(lightsrc0);
% title('提取对应颜色部分');
% subplot 122;
% imshow(lightsrc);
% title('提取颜色部分并进行二值化、闭运算后的图像');

end