                % 释放串口资源
                delete(instrfindall);
                % 创建串口资源
                app.Com_Obj = serial('COM6','BaudRate',115200);
                % 设置串口中断,接收到1个字节中断
                set(app.Com_Obj,'BytesAvailableFcnMode','byte');
                set(app.Com_Obj,'BytesAvailableFcnCount', 1);
                % 设置窗口接收回调
                app.Com_Obj.BytesAvailableFcn=@app.ComReceiveCallback;
                % 查询串口是否已经打开
                if(app.Com_Obj.Status == "closed")
                    % 打开串口
                    fopen(app.Com_Obj);
                    if(app.Com_Obj.Status == "open")
                        fprintf(1,'串口打开成功\n'); 
                    else
                        fprintf(1,'串口打开失败\n');     
                    end  
                else
                     fprintf(1,'串口被占用\n'); 
                end 