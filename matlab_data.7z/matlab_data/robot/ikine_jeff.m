T1 = transl(0.4, 0.2, 0) * trotx(pi);
T2 = transl(0.4, -0.2, 0) * trotx(pi/2);
q1 = ikine_jeff1(p560, T1);

q2 = ikine_jeff1(p560, T2);
% qi = p560.ikine6s(T);
t = [0:0.05:2]';

q = jtraj(q1, q2, t);
figure
p560.plot(q);

figure 
qplot(t,q);