%%改进D-H模型
%       关节角   连杆偏距    连杆长度  连杆转角   
%       theta(i) d(i)        a(i-1)   alpha(i-1)  offset
% SL1=Link([0      0           0        0           0     ],'modified');
% SL2=Link([0      0.14909     0        -pi/2       0     ],'modified');
% SL3=Link([0      0           0.4318   0           0     ],'modified');
% SL4=Link([0      0.43307     0.02032  -pi/2       0     ],'modified');
% SL5=Link([0      0           0        pi/2        0     ],'modified');
% SL6=Link([0      0           0        -pi/2       0     ],'modified');
% p2560=SerialLink([SL1 SL2 SL3 SL4 SL5 SL6],'name','puma560');%SerialLink 类函数
figure
p2560.plot([0 -0.8365 0.0938 0 -0.8281 0]);
% hold on
% figure
% qi = [pi -0.809746861 0.0945011079 3.14159274 -0.0466986783 1];
% p2560.plot(qi);