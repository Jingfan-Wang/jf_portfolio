function lightsrc0 = tiquyanse(rowG, rowR, rowY, lightsrc0, colG, src, colR, colY)

lightcolor=[size(rowG,1),size(rowR,1),size(rowY,1)];%各颜色范围像素点 
if max(lightcolor)==size(rowG,1)% 找包含最多像素点的颜色阈值范围，输出结果
    for i=1:length(rowG)
        lightsrc0(rowG(i),colG(i))=src(rowG(i),colG(i));% 将对应颜色区域进行提取
    end
%     figure;
%     imshow(src,'XData',[0 1920],'YData',[0 1080]);
%     title('信号灯为绿色');% 绿色范围像素点最多
else
    if max(lightcolor)==size(rowR,1)
        for i=1:length(rowR)
            lightsrc0(rowR(i),colR(i))=src(rowR(i),colR(i));
        end
%         figure;
%         imshow(src,'XData',[0 1920],'YData',[0 1080]);
%         title('信号灯为红色');
    else
        for i=1:length(rowY)
            lightsrc0(rowY(i),colY(i))=src(rowY(i),colY(i));
        end
%         figure;
%         imshow(src,'XData',[0 1920],'YData',[0 1080]);
%         title('信号灯为黄色');
    end
end
end