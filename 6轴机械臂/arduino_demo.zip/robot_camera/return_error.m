function [lightsrc, width, height, centre_x, centre_y,lightsrc1,lightx,lighty,error_x,error_y] = return_error(lightsrc)
lightsrc1=lightsrc;%进行对比比较存档
[L1,n1]=bwlabel(lightsrc);% 信号灯提取,采用连通分量，n1为连通分量个数
lightx=0;%为下一步的信号灯区域裁剪做准备
lighty=0;
width=0;
height=0;

centre_x=0;
centre_y=0;
error_x=0;
error_y=0;
DAXIAO=zeros(n1,1);
j=1;
for k=1:n1%对连通分量的范围进行约束
    [r,c]=find(L1==k);
    DAXIAO(k)=size(r,1);
    
end
   [size_daxiao,max_r_c] = max(DAXIAO);
for k =1:n1
    [r,c]=find(L1==k);
    if size(r,1)<size_daxiao-1 % 信号灯范围是300-6000
         for i=1:size(r,1)
            lightsrc(r(i),c(i))=0;%在信号灯范围之外，则将该连通分量置黑
        end
    else
        lightx=min(c);
        lighty=min(r);
        width=max(c)-min(c);
        height=max(r)-min(r);
        centre_x= lightx+width/2;
        centre_y= lighty+height/2;
        error_x=centre_x-960 ;
        error_y=centre_y- 540;
        j=j+1;
    end  
end

% figure;
% subplot 121;
% imshow(lightsrc1);
% title('范围约束前');
% subplot 122;
imshow(lightsrc);
title('范围约束后');
rectangle('Position',[lightx lighty width(1) height(1)] ,'LineWidth',3,'EdgeColor','g');

end