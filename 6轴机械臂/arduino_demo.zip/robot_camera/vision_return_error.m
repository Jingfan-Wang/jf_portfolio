function [errror_x ,errror_y]=vision_return_error(cam, x, y)
    img = snapshot(cam);
    image(x,y,img);
    title('Face Detection');
    FDetect = vision.CascadeObjectDetector;
    box_data = step(FDetect,img);%识别到人脸画框数据 格式为 矩形四顶点西北方向点横坐标 纵坐标 长度  宽度
     if isempty(box_data)
         errror_x=0;
         errror_y=0;
         return
     end
    centre_data=zeros(size(box_data,1),2);%计算出矩形中心位置横坐标 纵坐标 用来判断是否处于摄像头中心位置

    %for i = 1:size(box_data,1)
      centre_data(1,1)=box_data(1,1)+box_data(1,3)/2;
      centre_data(1,2)=box_data(1,2)+box_data(1,3)/2;
      rectangle('Position',box_data(1,:),'LineWidth',1,'LineStyle','-','EdgeColor','g');  % 画框  位置：数组 线框：粗细度 线型：'-' 边框颜色：'g'
      rectangle('Position',[centre_data(1,1) centre_data(1,2) 2 2] ,'LineWidth',1,'EdgeColor','r');

      errror_x= x(2)/2-centre_data(1);%大于0 为图像偏左  小于 0为图像偏右 最大值 为 x(2)/2
      errror_y= y(2)/2-centre_data(2);%大于0 为图像偏上  小于 0为图像偏下 最大值 为 x(2)/2

    %end
end