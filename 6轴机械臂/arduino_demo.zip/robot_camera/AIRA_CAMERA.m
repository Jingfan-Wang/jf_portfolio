% clear all
% clc
% %Detect objects using Viola-Jones Algorithm
%  
% %To detect Face
% FDetect = vision.CascadeObjectDetector;
%  
% %Read the input image
% I = imread('123.jpg');
%  
% %Returns Bounding Box values based on number of objects
% BB = step(FDetect,I);
% AA=zeros(size(BB,1),2);
% figure,
% image(I); 
% 
% hold on
% 
% for i = 1:size(BB,1)
%     AA(i,1)=BB(i,1)+BB(i,3)/2;
%     AA(i,2)=BB(i,2)+BB(i,3)/2;
%     rectangle('Position',BB(i,:),'LineWidth',1,'LineStyle','-','EdgeColor','g');  % 画框  位置：数组 线框：粗细度 线型：'-' 边框颜色：'g'
% 
%     rectangle('Position',[AA(i,1) AA(i,2) 2 2] ,'LineWidth',1,'EdgeColor','r');
% end
% 
% title('Face Detection');
% hold off;
[cam, x, y] = vision_camera_INIT;
[ERRORX, ERRORY]=vision_return_error(cam, x, y);
    ERRORX_last=0;
    ERRORY_last=0;
    %传输上下左右控制指令
    Kp=1.0;Kd=0;
    %位置式pd 
    Out_left_right = Kp *(ERRORX) + Kd * (ERRORX-ERRORX_last); %F1
    Out_up_down    = Kp *(ERRORY) + Kd * (ERRORY-ERRORY_last);%F3 
    
    ERRORX_last = ERRORX;
    ERRORY_last = ERRORY;
    
    Out_left_right= Out_left_right/1000;
    Out_up_down= Out_up_down/1000;
    %舵机限幅
    if(Out_left_right>1)
        Out_left_right=1;
    end

    if(Out_up_down>1)
        Out_up_down=1;
    end

    if(Out_left_right<0)
        Out_left_right=0;
    end

    if(Out_up_down<0)
        Out_up_down=0;
    end