function [lightsrc0, rowG, colG, rowR, colR, rowY, colY] = RGB_2_HSV_(src)
light_hsv=rgb2hsv(src);% rgb2hsv:色调、对比度、亮度
H=light_hsv(:,:,1);
S=light_hsv(:,:,2);
V=light_hsv(:,:,3);

% figure ;% 作图
% imshow(src,'XData',[0 2000],'YData',[0 1100]);
% set(gca,'xtick',0:100:2000);
% set(gca,'ytick',0:100:1100);
% title('原始图像');
% 
% figure ;
% imshow(H,'XData',[0 2000],'YData',[0 1100]);
% xlim([0 2000]);
% ylim([0 1100]);
% title('H分量');
% 
% figure ;
% imshow(S,'XData',[0 2000],'YData',[0 1100]);
% xlim([0 2000]);
% ylim([0 1100]);
% title('S分量');
% 
% figure ;
% imshow(V,'XData',[0 2000],'YData',[0 1100]);
% xlim([0 2000]);
% ylim([0 1100]);
% title('V分量');

lightsrc0=zeros(size(src));% 设置lightsrc0来对三色范围像素点进行存储
[rowG,colG]=ind2sub(size(light_hsv),find(H>0.4 & H<0.55 & S>0.16 & S<1 & V>0.9));% 绿色阈值范围
[rowR,colR]=ind2sub(size(light_hsv),find(H>0.9 & S>0.4 & V>0.4));% 红色阈值范围
[rowY,colY]=ind2sub(size(light_hsv),find(H>0.09 & H<0.4 & S>0.16 & S<1 & V>0.8));% 黄色阈值范围
end